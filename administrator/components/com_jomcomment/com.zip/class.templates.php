<?php

/**
* Jom Comment 
* @version 1.0
* @package JomComment
* @copyright (C) 2006 by Azrul Rahim - All rights reserved!
* @license Copyrighted Commercial Software
**/

(defined('_VALID_MOS') OR defined('_JEXEC')) or die('Direct Access to this location is not allowed.');
