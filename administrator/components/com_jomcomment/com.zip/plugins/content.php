<?php

/**
* @copyright (C) 2007 by Slashes & Dots Sdn Bhd - All rights reserved!
* @license http://www.azrul.com Copyrighted Commercial Software
**/

(defined('_VALID_MOS') OR defined('_JEXEC')) or die('Direct Access to this location is not allowed.');
