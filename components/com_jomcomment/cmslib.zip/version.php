<?php
global $cmsVersion;

$cmsVersion	= floatval('1.1');
